package com.example;

import com.example.entity.Student;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class App {

    public static void main(String[] args) {
        try {
            // ---------- 1. INSERT ----------
            String email = "john.doe." + System.currentTimeMillis() + "@example.com";
            Student student = new Student("John Doe", email, "Computer Science");

            Long id;
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Transaction tx = session.beginTransaction();
                session.persist(student);
                tx.commit();
                id = student.getId();
            }
            System.out.println("\n[INSERT] Student saved with ID = " + id);

            // ---------- 2. VERIFY INSERT ----------
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Student saved = session.get(Student.class, id);
                if (saved == null) {
                    throw new IllegalStateException("Insert verification FAILED: record not found");
                }
                System.out.println("[VERIFY INSERT] Found in DB: " + saved);
            }

            // ---------- 3. UPDATE ----------
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Transaction tx = session.beginTransaction();
                Student toUpdate = session.get(Student.class, id);
                toUpdate.setName("John A. Doe");
                toUpdate.setCourse("Data Science");
                tx.commit();
            }
            System.out.println("[UPDATE] Student with ID " + id + " updated");

            // ---------- 4. VERIFY UPDATE ----------
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                Student updated = session.get(Student.class, id);
                boolean ok = "John A. Doe".equals(updated.getName())
                          && "Data Science".equals(updated.getCourse());
                System.out.println("[VERIFY UPDATE] " + updated);
                System.out.println(ok ? "SUCCESS: update verified in database."
                                      : "FAILED: update not reflected in database.");
            }

            // ---------- 5. LIST ALL ----------
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                List<Student> all = session.createQuery("from Student", Student.class).list();
                System.out.println("\nAll students in table (" + all.size() + "):");
                all.forEach(System.out::println);
            }
        } finally {
            HibernateUtil.shutdown();
        }
    }
}
